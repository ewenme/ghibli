library(testthat)
library(desc)

test_check("desc")

function_with_unusual_name <- function() {
  print("Hi!")
}
# infrastructure

The goal of infrastructure is to ...

## Example

This is a basic example which shows you how to solve a common problem:

``` r
## basic example code
```

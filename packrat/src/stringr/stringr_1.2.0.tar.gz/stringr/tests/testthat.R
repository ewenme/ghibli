library(testthat)
library(stringr)

test_check("stringr")
